import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight

class CSVEEGDataset(Dataset):
    def __init__(self, csv_path, label_col):
        data = pd.read_csv(csv_path)
        features = data.drop(columns=[label_col])
        labels = data[label_col]

        scaler = StandardScaler()
        self.features = torch.tensor(scaler.fit_transform(features), dtype=torch.float32)

        le = LabelEncoder()
        self.labels = torch.tensor(le.fit_transform(labels), dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]

class FedLEUTransformer(nn.Module):
    def __init__(self, input_dim=178, hidden_dim=256, num_classes=2):
        super(FedLEUTransformer, self).__init__()

        self.preprocess = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.Tanh()
        )

        self.decompose = nn.ModuleList([nn.Linear(input_dim, input_dim) for _ in range(5)])

        self.extractor = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU()
        )

        self.attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.Softmax(dim=-1)
        )

        encoder_layer = nn.TransformerEncoderLayer(d_model=hidden_dim, nhead=8, dropout=0.3)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=6)

        self.classifier = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.preprocess(x)  
        x = torch.stack([layer(x) for layer in self.decompose], dim=1)  
        x = self.extractor(x) 
        x = self.attention(x)  
        x = self.transformer(x)  
        x = x.mean(dim=1) 
        return self.classifier(x)

def train(model, loader, criterion, optimizer, scheduler, epochs=100):
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for inputs, labels in loader:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        scheduler.step()
        print(f"Epoch {epoch+1}/{epochs}: Total Loss = {total_loss:.4f}")

def evaluate(model, loader):
    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for inputs, labels in loader:
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    y_true = np.array(all_labels)
    y_pred = np.array(all_preds)

    acc = accuracy_score(y_true, y_pred) * 100
    prec = precision_score(y_true, y_pred, average='weighted', zero_division=0) * 100
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0) * 100
    f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0) * 100

    specificity = 0
    if len(np.unique(y_true)) == 2:
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        specificity = tn / (tn + fp) * 100 if (tn + fp) > 0 else 0

    print(f"\n--- Evaluation Metrics ---")
    print(f"Accuracy      (%): {acc:.2f}")
    print(f"Precision     (%): {prec:.2f}")
    print(f"Recall        (%): {recall:.2f}")
    print(f"Specificity   (%): {specificity:.2f}")
    print(f"F1-Score      (%): {f1:.2f}")

csv_path = r"Enter\your\dataset\path\here\preprocess_data.csv"
label_column = "Label"

df = pd.read_csv(csv_path)
input_dim = df.shape[1] - 1
num_classes = len(df[label_column].unique())

class_weights = compute_class_weight('balanced', classes=np.unique(df[label_column]), y=df[label_column])
class_weights_tensor = torch.tensor(class_weights, dtype=torch.float32)

dataset = CSVEEGDataset(csv_path, label_col=label_column)
train_size = int(0.9 * len(dataset))
test_size = len(dataset) - train_size
train_set, test_set = random_split(dataset, [train_size, test_size])

train_loader = DataLoader(train_set, batch_size=64, shuffle=True)
test_loader = DataLoader(test_set, batch_size=64)

model = FedLEUTransformer(input_dim=input_dim, num_classes=num_classes)
optimizer = optim.Adam(model.parameters(), lr=0.0001)
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=40, gamma=0.5)
criterion = nn.CrossEntropyLoss(weight=class_weights_tensor)

train(model, train_loader, criterion, optimizer, scheduler, epochs=100)
evaluate(model, test_loader)